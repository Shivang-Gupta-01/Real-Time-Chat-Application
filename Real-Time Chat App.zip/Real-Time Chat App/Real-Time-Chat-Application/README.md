# Real Time Chat Application
 This is a real time chat application made using Express.js, Node.js and Socket.io where users can enter any room they want and and start texting
